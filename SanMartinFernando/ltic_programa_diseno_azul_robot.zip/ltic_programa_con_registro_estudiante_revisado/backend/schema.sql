-- Base de datos esperada por backend/server.js:
-- CREATE DATABASE ltic_prestamos;
-- Luego conectarse a ltic_prestamos y ejecutar este script.

CREATE TABLE IF NOT EXISTS estudiantes (
  id SERIAL PRIMARY KEY,
  carrera VARCHAR(150) NOT NULL,
  facultad VARCHAR(150) NOT NULL,
  tipo_id VARCHAR(30) NOT NULL,
  identificacion VARCHAR(30) NOT NULL UNIQUE,
  nombre VARCHAR(150) NOT NULL,
  celular VARCHAR(20) NOT NULL,
  correo VARCHAR(150) NOT NULL,
  telefono VARCHAR(20),
  direccion TEXT,
  creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS prestamos (
  id SERIAL PRIMARY KEY,
  codigo VARCHAR(30) NOT NULL UNIQUE,
  tipo VARCHAR(80) NOT NULL,
  periodo_academico VARCHAR(100),
  laboratorio VARCHAR(100),
  responsable VARCHAR(150),
  solicitante_tipo VARCHAR(50),
  estudiante_id INTEGER REFERENCES estudiantes(id),
  creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS articulos_prestamo (
  id SERIAL PRIMARY KEY,
  prestamo_id INTEGER NOT NULL REFERENCES prestamos(id) ON DELETE CASCADE,
  articulo VARCHAR(150) NOT NULL,
  cantidad INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS devoluciones (
  id SERIAL PRIMARY KEY,
  prestamo_id INTEGER REFERENCES prestamos(id),
  observacion TEXT,
  creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
