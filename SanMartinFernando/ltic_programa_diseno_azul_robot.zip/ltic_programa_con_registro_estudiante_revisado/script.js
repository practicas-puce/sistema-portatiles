const secciones = document.querySelectorAll(".seccion");
const enlacesNav = document.querySelectorAll(".enlace-nav");
const botonesIr = document.querySelectorAll("[data-ir]");
const botonMenu = document.getElementById("botonMenu");
const menuPrincipal = document.getElementById("menuPrincipal");
const usuario = document.querySelector(".usuario");
const botonesPrestamo = document.querySelectorAll("[data-panel-prestamo]");
const panelesPrestamo = document.querySelectorAll(".subseccion-prestamo");
const botonCerrarSesion = document.getElementById("botonCerrarSesion");

function mostrarSeccion(idSeccion) {
    secciones.forEach(function (seccion) {
        seccion.classList.toggle("activa", seccion.id === idSeccion);
    });

    enlacesNav.forEach(function (enlace) {
        enlace.classList.toggle("activo", enlace.dataset.seccion === idSeccion);
    });

    window.location.hash = idSeccion;
    cerrarMenuMovil();
}

function mostrarPanelPrestamo(idPanel) {
    panelesPrestamo.forEach(function (panel) {
        panel.classList.toggle("activa", panel.id === idPanel);
    });

    botonesPrestamo.forEach(function (boton) {
        boton.classList.toggle("activo", boton.dataset.panelPrestamo === idPanel);
    });
}

function cerrarMenuMovil() {
    if (menuPrincipal) {
        menuPrincipal.classList.remove("abierto");
    }

    if (usuario) {
        usuario.classList.remove("abierto");
    }
}

enlacesNav.forEach(function (enlace) {
    enlace.addEventListener("click", function (evento) {
        evento.preventDefault();
        mostrarSeccion(enlace.dataset.seccion);
    });
});

botonesIr.forEach(function (boton) {
    boton.addEventListener("click", function () {
        mostrarSeccion(boton.dataset.ir);
    });
});

botonesPrestamo.forEach(function (boton) {
    boton.addEventListener("click", function () {
        mostrarPanelPrestamo(boton.dataset.panelPrestamo);
    });
});

if (botonMenu) {
    botonMenu.addEventListener("click", function () {
        menuPrincipal.classList.toggle("abierto");
        usuario.classList.toggle("abierto");
    });
}

if (botonCerrarSesion) {
    botonCerrarSesion.addEventListener("click", function () {
        alert("Sesión cerrada correctamente.");
    });
}

const seccionInicial = window.location.hash.replace("#", "") || "home";
mostrarSeccion(seccionInicial);
mostrarPanelPrestamo("prestamoNormal");

function obtenerValor(id) {
    const elemento = document.getElementById(id);
    return elemento ? elemento.value.trim() : "";
}

function limpiarErrores(ids) {
    ids.forEach(function (id) {
        const campo = document.getElementById(id);
        const error = document.getElementById(`error-${id}`);

        if (campo) {
            campo.classList.remove("campo-error");
        }

        if (error) {
            error.textContent = "";
        }
    });

    const errorArticulos = document.getElementById("error-articulosPrestamo");
    if (errorArticulos) {
        errorArticulos.textContent = "";
    }
}

function mostrarError(id, texto) {
    const campo = document.getElementById(id);
    const error = document.getElementById(`error-${id}`);

    if (campo) {
        campo.classList.add("campo-error");
    }

    if (error) {
        error.textContent = texto;
    }
}

function validarTexto(id, mensaje) {
    if (obtenerValor(id) === "") {
        mostrarError(id, mensaje);
        return false;
    }
    return true;
}

function validarCorreo(id) {
    const correo = obtenerValor(id);

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo)) {
        mostrarError(id, "Ingrese un correo electrónico válido.");
        return false;
    }
    return true;
}

function validarCelular(id) {
    const celular = obtenerValor(id);

    if (!/^09\d{8}$/.test(celular)) {
        mostrarError(id, "Ingrese un celular válido. Ejemplo: 0999999999.");
        return false;
    }
    return true;
}

function validarIdentificacion(tipoId, numeroId) {
    const tipo = obtenerValor(tipoId);
    const numero = obtenerValor(numeroId);

    if (tipo === "") {
        mostrarError(tipoId, "Seleccione el tipo de identificación.");
        return false;
    }

    if (tipo === "Cédula" && !/^\d{10}$/.test(numero)) {
        mostrarError(numeroId, "La cédula debe tener 10 números.");
        return false;
    }

    if (tipo === "Pasaporte" && !/^[A-Za-z0-9]{6,15}$/.test(numero)) {
        mostrarError(numeroId, "El pasaporte debe tener entre 6 y 15 caracteres.");
        return false;
    }

    return true;
}

function guardarEnLocalStorage(clave, registro) {
    const datosGuardados = JSON.parse(localStorage.getItem(clave)) || [];
    datosGuardados.push(registro);
    localStorage.setItem(clave, JSON.stringify(datosGuardados));
}

function obtenerRegistros(clave) {
    return JSON.parse(localStorage.getItem(clave)) || [];
}

function obtenerEstudiantesRegistrados() {
    return obtenerRegistros("estudiantesLTIC");
}

function obtenerNombresEstudiantes() {
    const estudiantesBase = ["Estudiante 1", "Estudiante 2", "Estudiante 3"];
    const registrados = obtenerEstudiantesRegistrados().map(function (estudiante) {
        return estudiante.nombre;
    }).filter(function (nombre) {
        return nombre && nombre.trim() !== "";
    });

    return Array.from(new Set(estudiantesBase.concat(registrados)));
}

function seleccionarEstudianteEnPrestamo(nombre) {
    const select = document.getElementById("solicitantePrestamo");

    if (!select || !nombre) {
        return;
    }

    let existe = false;
    Array.from(select.options).forEach(function (opcion) {
        if (opcion.value === nombre) {
            existe = true;
        }
    });

    if (!existe) {
        const opcion = document.createElement("option");
        opcion.value = nombre;
        opcion.textContent = nombre;
        select.appendChild(opcion);
    }

    select.value = nombre;
}

function mostrarMensaje(idMensaje, texto, tipo) {
    const mensaje = document.getElementById(idMensaje);

    if (!mensaje) {
        return;
    }

    mensaje.textContent = texto;
    mensaje.className = `mensaje ${tipo}`;
}

function crearCodigoPrestamo() {
    return Date.now().toString().slice(-5);
}

function formatearFechaHoraSistema() {
    const fecha = new Date();
    const anio = fecha.getFullYear();
    const mes = String(fecha.getMonth() + 1).padStart(2, "0");
    const dia = String(fecha.getDate()).padStart(2, "0");
    const horas = String(fecha.getHours()).padStart(2, "0");
    const minutos = String(fecha.getMinutes()).padStart(2, "0");
    const segundos = String(fecha.getSeconds()).padStart(2, "0");
    return `${anio}-${mes}-${dia} ${horas}:${minutos}:${segundos}`;
}

function actualizarDatosAutomaticosPrestamo() {
    const numeroPrestamo = document.getElementById("numeroPrestamo");
    const fechaPrestamo = document.getElementById("fechaPrestamo");

    if (numeroPrestamo && numeroPrestamo.value === "") {
        numeroPrestamo.value = crearCodigoPrestamo();
    }

    if (fechaPrestamo) {
        fechaPrestamo.value = formatearFechaHoraSistema();
    }
}

function obtenerTipoSolicitante() {
    const seleccionado = document.querySelector('input[name="tipoSolicitante"]:checked');
    return seleccionado ? seleccionado.value : "Estudiante";
}

function configurarTipoSolicitante() {
    const radios = document.querySelectorAll('input[name="tipoSolicitante"]');
    const select = document.getElementById("solicitantePrestamo");
    const botonAgregar = document.getElementById("botonAgregarSolicitante");

    function actualizar() {
        const tipo = obtenerTipoSolicitante();

        if (!select || !botonAgregar) {
            return;
        }

        select.innerHTML = "";

        const opcionInicial = document.createElement("option");
        opcionInicial.value = "";
        opcionInicial.textContent = tipo === "Estudiante"
            ? "-- Seleccione al estudiante que solicita el préstamo --"
            : "-- Seleccione al profesor que solicita el préstamo --";
        select.appendChild(opcionInicial);

        const opciones = tipo === "Estudiante"
            ? obtenerNombresEstudiantes()
            : ["Profesor 1", "Profesor 2", "Profesor 3"];

        opciones.forEach(function (nombre) {
            const opcion = document.createElement("option");
            opcion.value = nombre;
            opcion.textContent = nombre;
            select.appendChild(opcion);
        });

        botonAgregar.textContent = tipo === "Estudiante"
            ? "Agregar un nuevo Estudiante"
            : "Agregar un nuevo Profesor";
    }

    radios.forEach(function (radio) {
        radio.addEventListener("change", actualizar);
    });

    actualizar();
}

function agregarSolicitante() {
    const tipo = obtenerTipoSolicitante();

    if (tipo === "Estudiante") {
        mostrarSeccion("registroEstudiante");
        const campoNombre = document.getElementById("registroNombre");
        if (campoNombre) {
            setTimeout(function () {
                campoNombre.focus();
            }, 100);
        }
        return;
    }

    const select = document.getElementById("solicitantePrestamo");
    const nombre = prompt("Ingrese el nombre del nuevo profesor:");

    if (!nombre || nombre.trim() === "" || !select) {
        return;
    }

    const opcion = document.createElement("option");
    opcion.value = nombre.trim();
    opcion.textContent = nombre.trim();
    opcion.selected = true;
    select.appendChild(opcion);
}

function crearFilaArticulo(articulo = "", cantidad = "") {
    const cuerpo = document.getElementById("cuerpoArticulos");

    if (!cuerpo) {
        return;
    }

    const fila = document.createElement("tr");
    fila.innerHTML = `
        <td>
            <select class="articulo-prestamo">
                <option value="">-- Seleccione un artículo --</option>
                <option value="Laptop">Laptop</option>
                <option value="Proyector">Proyector</option>
                <option value="Cable HDMI">Cable HDMI</option>
                <option value="Mouse">Mouse</option>
                <option value="Teclado">Teclado</option>
                <option value="Parlante">Parlante</option>
                <option value="Otro">Otro</option>
            </select>
        </td>
        <td>
            <input class="cantidad-articulo" type="number" min="1" placeholder="Cantidad" value="${cantidad}">
        </td>
        <td>
            <button class="boton-eliminar" type="button">Eliminar</button>
        </td>
    `;

    cuerpo.appendChild(fila);

    const select = fila.querySelector(".articulo-prestamo");
    select.value = articulo;

    fila.querySelector(".boton-eliminar").addEventListener("click", function () {
        fila.remove();
    });
}

function obtenerArticulosPrestamo() {
    const filas = document.querySelectorAll("#cuerpoArticulos tr");
    const articulos = [];

    filas.forEach(function (fila) {
        const articulo = fila.querySelector(".articulo-prestamo").value.trim();
        const cantidad = fila.querySelector(".cantidad-articulo").value.trim();

        if (articulo !== "" || cantidad !== "") {
            articulos.push({ articulo, cantidad });
        }
    });

    return articulos;
}

function validarArticulosPrestamo() {
    const error = document.getElementById("error-articulosPrestamo");
    const articulos = obtenerArticulosPrestamo();

    if (articulos.length === 0) {
        if (error) {
            error.textContent = "Agregue al menos un artículo al préstamo.";
        }
        return false;
    }

    const incompleto = articulos.some(function (item) {
        return item.articulo === "" || item.cantidad === "" || Number(item.cantidad) <= 0;
    });

    if (incompleto) {
        if (error) {
            error.textContent = "Complete el artículo y la cantidad. La cantidad debe ser mayor a cero.";
        }
        return false;
    }

    if (error) {
        error.textContent = "";
    }
    return true;
}

function limpiarFormularioPrestamoNormal() {
    const formularioPrestamo = document.getElementById("formularioPrestamo");
    const cuerpo = document.getElementById("cuerpoArticulos");

    if (formularioPrestamo) {
        formularioPrestamo.reset();
    }

    if (cuerpo) {
        cuerpo.innerHTML = "";
    }

    configurarTipoSolicitante();
    actualizarDatosAutomaticosPrestamo();
    crearFilaArticulo();
    mostrarMensaje("mensajePrestamo", "", "");
}

function claseEstado(estado) {
    if (estado === "Bueno") {
        return "estado-bueno";
    }

    if (estado === "Dañado") {
        return "estado-danado";
    }

    return "estado-novedad";
}

function renderizarPrestamos() {
    const contenedor = document.getElementById("listaPrestamos");

    if (!contenedor) {
        return;
    }

    const prestamos = obtenerRegistros("prestamosNormalesLTIC");

    if (prestamos.length === 0) {
        contenedor.innerHTML = '<p class="vacio">Todavía no existen préstamos normales registrados.</p>';
        return;
    }

    contenedor.innerHTML = prestamos.map(function (prestamo) {
        const articulos = Array.isArray(prestamo.articulos)
            ? prestamo.articulos.map(function (item) {
                return `${item.articulo} (${item.cantidad})`;
            }).join(", ")
            : prestamo.recurso || "Sin artículo";

        return `
            <article class="registro-card">
                <strong>Préstamo ${prestamo.codigo}</strong>
                <div>
                    <span>Tipo: ${prestamo.tipo}</span>
                    <span>Responsable: ${prestamo.responsable}</span>
                    <span>Solicitante: ${prestamo.solicitante}</span>
                    <span>Laboratorio: ${prestamo.laboratorio}</span>
                    <span>Fecha: ${prestamo.fecha}</span>
                </div>
                <p>Artículos: ${articulos}</p>
            </article>
        `;
    }).join("");
}

function renderizarDevoluciones() {
    const contenedor = document.getElementById("listaDevoluciones");

    if (!contenedor) {
        return;
    }

    const devoluciones = obtenerRegistros("devolucionesLTIC");

    if (devoluciones.length === 0) {
        contenedor.innerHTML = '<p class="vacio">Todavía no existen devoluciones registradas.</p>';
        return;
    }

    contenedor.innerHTML = devoluciones.map(function (devolucion) {
        return `
            <article class="registro-card">
                <strong>${devolucion.nombre}</strong>
                <div>
                    <span class="codigo">Código: ${devolucion.codigo}</span>
                    <span>Identificación: ${devolucion.numeroId}</span>
                    <span>Recurso: ${devolucion.recurso}</span>
                    <span>Fecha: ${devolucion.fecha}</span>
                    <span>Hora: ${devolucion.hora}</span>
                    <span class="${claseEstado(devolucion.estado)}">Estado: ${devolucion.estado}</span>
                </div>
                <p>${devolucion.observacion || "Sin observación."}</p>
            </article>
        `;
    }).join("");
}

function renderizarServicios() {
    const contenedor = document.getElementById("listaServicios");

    if (!contenedor) {
        return;
    }

    const servicios = obtenerRegistros("serviciosLTIC");

    if (servicios.length === 0) {
        contenedor.innerHTML = '<p class="vacio">Todavía no existen servicios registrados.</p>';
        return;
    }

    contenedor.innerHTML = servicios.map(function (servicio) {
        return `
            <article class="registro-card">
                <strong>${servicio.nombre}</strong>
                <div>
                    <span>Servicio: ${servicio.tipoServicio}</span>
                    <span>Fecha requerida: ${servicio.fecha}</span>
                    <span>Celular: ${servicio.celular}</span>
                </div>
                <p>${servicio.descripcion}</p>
            </article>
        `;
    }).join("");
}

const botonAgregarSolicitante = document.getElementById("botonAgregarSolicitante");
if (botonAgregarSolicitante) {
    botonAgregarSolicitante.addEventListener("click", agregarSolicitante);
}

const botonAgregarArticulo = document.getElementById("botonAgregarArticulo");
if (botonAgregarArticulo) {
    botonAgregarArticulo.addEventListener("click", function () {
        crearFilaArticulo();
    });
}

const botonCancelarPrestamo = document.getElementById("botonCancelarPrestamo");
if (botonCancelarPrestamo) {
    botonCancelarPrestamo.addEventListener("click", limpiarFormularioPrestamoNormal);
}

const formularioPrestamo = document.getElementById("formularioPrestamo");
if (formularioPrestamo) {
    formularioPrestamo.addEventListener("submit", function (evento) {
        evento.preventDefault();

        const camposPrestamo = [
            "responsablePrestamo",
            "solicitantePrestamo"
        ];

        limpiarErrores(camposPrestamo);

        let valido = true;
        valido = validarTexto("responsablePrestamo", "Seleccione el responsable del préstamo.") && valido;
        valido = validarTexto("solicitantePrestamo", "Seleccione el solicitante del préstamo.") && valido;
        valido = validarArticulosPrestamo() && valido;

        if (!valido) {
            mostrarMensaje("mensajePrestamo", "Revise los campos marcados.", "fallo");
            return;
        }

        const prestamo = {
            codigo: obtenerValor("numeroPrestamo"),
            tipo: obtenerValor("tipoPrestamoFijo"),
            periodo: obtenerValor("periodoAcademico"),
            laboratorio: obtenerValor("laboratorioPrestamo"),
            fecha: obtenerValor("fechaPrestamo"),
            responsable: obtenerValor("responsablePrestamo"),
            tipoSolicitante: obtenerTipoSolicitante(),
            solicitante: obtenerValor("solicitantePrestamo"),
            articulos: obtenerArticulosPrestamo(),
            fechaRegistro: new Date().toLocaleString("es-EC")
        };

        guardarEnLocalStorage("prestamosNormalesLTIC", prestamo);
        mostrarMensaje("mensajePrestamo", `Préstamo normal guardado correctamente. Código: ${prestamo.codigo}`, "exito");
        renderizarPrestamos();
        limpiarFormularioPrestamoNormal();
    });
}


const botonVolverPrestamoNormal = document.getElementById("botonVolverPrestamoNormal");
if (botonVolverPrestamoNormal) {
    botonVolverPrestamoNormal.addEventListener("click", function () {
        mostrarSeccion("prestamos");
        mostrarPanelPrestamo("prestamoNormal");
    });
}

const formularioRegistroEstudiante = document.getElementById("formularioRegistroEstudiante");
if (formularioRegistroEstudiante) {
    formularioRegistroEstudiante.addEventListener("submit", function (evento) {
        evento.preventDefault();

        const camposRegistro = [
            "registroCarrera",
            "registroFacultad",
            "registroTipoId",
            "registroNumeroId",
            "registroNombre",
            "registroCelular",
            "registroCorreo"
        ];

        limpiarErrores(camposRegistro);

        let valido = true;
        valido = validarTexto("registroCarrera", "Ingrese la carrera.") && valido;
        valido = validarTexto("registroFacultad", "Ingrese la facultad.") && valido;
        valido = validarIdentificacion("registroTipoId", "registroNumeroId") && valido;
        valido = validarTexto("registroNombre", "Ingrese el nombre completo.") && valido;
        valido = validarCelular("registroCelular") && valido;
        valido = validarCorreo("registroCorreo") && valido;

        if (!valido) {
            mostrarMensaje("mensajeRegistroEstudiante", "Revise los campos marcados.", "fallo");
            return;
        }

        const estudiante = {
            carrera: obtenerValor("registroCarrera"),
            facultad: obtenerValor("registroFacultad"),
            tipoId: obtenerValor("registroTipoId"),
            numeroID: obtenerValor("registroNumeroId"),
            nombre: obtenerValor("registroNombre"),
            celular: obtenerValor("registroCelular"),
            correo: obtenerValor("registroCorreo"),
            fechaRegistro: new Date().toLocaleString("es-EC")
        };

        guardarEnLocalStorage("estudiantesLTIC", estudiante);
        guardarEnLocalStorage("registrosLTIC", estudiante);
        formularioRegistroEstudiante.reset();
        mostrarMensaje("mensajeRegistroEstudiante", "Estudiante registrado correctamente. Ahora puede seleccionarlo en Préstamo Normal.", "exito");
        configurarTipoSolicitante();
        seleccionarEstudianteEnPrestamo(estudiante.nombre);
    });
}

const formularioDevolucion = document.getElementById("formularioDevolucion");
if (formularioDevolucion) {
    formularioDevolucion.addEventListener("submit", function (evento) {
        evento.preventDefault();

        const camposDevolucion = [
            "devolucionCodigo",
            "devolucionNumeroId",
            "devolucionNombre",
            "devolucionRecurso",
            "devolucionFecha",
            "devolucionHora",
            "devolucionEstado"
        ];

        limpiarErrores(camposDevolucion);

        let valido = true;
        valido = validarTexto("devolucionCodigo", "Ingrese el código del préstamo.") && valido;
        valido = validarTexto("devolucionNumeroId", "Ingrese la identificación.") && valido;
        valido = validarTexto("devolucionNombre", "Ingrese el nombre completo.") && valido;
        valido = validarTexto("devolucionRecurso", "Ingrese el recurso devuelto.") && valido;
        valido = validarTexto("devolucionFecha", "Seleccione la fecha de devolución.") && valido;
        valido = validarTexto("devolucionHora", "Seleccione la hora de devolución.") && valido;
        valido = validarTexto("devolucionEstado", "Seleccione el estado del recurso.") && valido;

        if (!valido) {
            mostrarMensaje("mensajeDevolucion", "Revise los campos marcados.", "fallo");
            return;
        }

        const devolucion = {
            codigo: obtenerValor("devolucionCodigo"),
            numeroId: obtenerValor("devolucionNumeroId"),
            nombre: obtenerValor("devolucionNombre"),
            recurso: obtenerValor("devolucionRecurso"),
            fecha: obtenerValor("devolucionFecha"),
            hora: obtenerValor("devolucionHora"),
            estado: obtenerValor("devolucionEstado"),
            observacion: obtenerValor("devolucionObservacion"),
            fechaRegistro: new Date().toLocaleString("es-EC")
        };

        guardarEnLocalStorage("devolucionesLTIC", devolucion);
        formularioDevolucion.reset();
        mostrarMensaje("mensajeDevolucion", "Devolución guardada correctamente.", "exito");
        renderizarDevoluciones();
    });
}

const formularioServicio = document.getElementById("formularioServicio");
if (formularioServicio) {
    formularioServicio.addEventListener("submit", function (evento) {
        evento.preventDefault();

        const camposServicio = [
            "servicioCarrera",
            "servicioFacultad",
            "servicioTipoId",
            "servicioNumeroId",
            "servicioNombre",
            "servicioCelular",
            "servicioCorreo",
            "tipoServicio",
            "fechaServicio",
            "descripcionServicio"
        ];

        limpiarErrores(camposServicio);

        let valido = true;
        valido = validarTexto("servicioCarrera", "Ingrese la carrera.") && valido;
        valido = validarTexto("servicioFacultad", "Ingrese la facultad.") && valido;
        valido = validarIdentificacion("servicioTipoId", "servicioNumeroId") && valido;
        valido = validarTexto("servicioNombre", "Ingrese el nombre completo.") && valido;
        valido = validarCelular("servicioCelular") && valido;
        valido = validarCorreo("servicioCorreo") && valido;
        valido = validarTexto("tipoServicio", "Seleccione el servicio.") && valido;
        valido = validarTexto("fechaServicio", "Seleccione la fecha requerida.") && valido;
        valido = validarTexto("descripcionServicio", "Ingrese la descripción del requerimiento.") && valido;

        if (!valido) {
            mostrarMensaje("mensajeServicio", "Revise los campos marcados.", "fallo");
            return;
        }

        const servicio = {
            carrera: obtenerValor("servicioCarrera"),
            facultad: obtenerValor("servicioFacultad"),
            tipoId: obtenerValor("servicioTipoId"),
            numeroId: obtenerValor("servicioNumeroId"),
            nombre: obtenerValor("servicioNombre"),
            celular: obtenerValor("servicioCelular"),
            correo: obtenerValor("servicioCorreo"),
            tipoServicio: obtenerValor("tipoServicio"),
            fecha: obtenerValor("fechaServicio"),
            descripcion: obtenerValor("descripcionServicio"),
            fechaRegistro: new Date().toLocaleString("es-EC")
        };

        guardarEnLocalStorage("serviciosLTIC", servicio);
        formularioServicio.reset();
        mostrarMensaje("mensajeServicio", "Servicio guardado correctamente.", "exito");
        renderizarServicios();
    });
}

configurarTipoSolicitante();
actualizarDatosAutomaticosPrestamo();
crearFilaArticulo();
setInterval(actualizarDatosAutomaticosPrestamo, 1000);
renderizarPrestamos();
renderizarDevoluciones();
renderizarServicios();
