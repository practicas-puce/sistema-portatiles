const http = require("node:http");
const { URL } = require("node:url");
const fs = require("node:fs");
const path = require("node:path");
const { Pool } = require("pg");

const PORT = process.env.PORT || 3000;
const FRONTEND_DIR = path.resolve(__dirname, "..");

const pool = new Pool({
  user: process.env.DB_USER || "postgres",
  host: process.env.DB_HOST || "localhost",
  database: process.env.DB_NAME || "ltic_prestamos",
  password: process.env.DB_PASSWORD || "1234",
  port: Number(process.env.DB_PORT || 5432),
});

const tiposMime = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
};

function enviarJSON(res, status, data) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
  });

  res.end(JSON.stringify(data));
}

function servirArchivo(res, rutaSolicitada) {
  const rutaLimpia = rutaSolicitada === "/" ? "/index.html" : rutaSolicitada;
  const rutaDecodificada = decodeURIComponent(rutaLimpia.split("?")[0]);
  const archivo = path.normalize(path.join(FRONTEND_DIR, rutaDecodificada));

  // Evita que se acceda a archivos fuera de la carpeta del proyecto.
  if (!archivo.startsWith(FRONTEND_DIR)) {
    enviarJSON(res, 403, { error: "Acceso no permitido" });
    return;
  }

  fs.readFile(archivo, (error, contenido) => {
    if (error) {
      enviarJSON(res, 404, { error: "Archivo no encontrado" });
      return;
    }

    const extension = path.extname(archivo).toLowerCase();
    res.writeHead(200, {
      "Content-Type": tiposMime[extension] || "application/octet-stream",
    });
    res.end(contenido);
  });
}

function leerBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";

    req.on("data", (chunk) => {
      body += chunk.toString();
    });

    req.on("end", () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (error) {
        reject(error);
      }
    });
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);

  if (req.method === "OPTIONS") {
    enviarJSON(res, 200, { mensaje: "OK" });
    return;
  }

  try {
    if (req.method === "GET" && url.pathname === "/api/salud") {
      enviarJSON(res, 200, { mensaje: "Servidor conectado correctamente" });
      return;
    }

    if (req.method === "GET" && url.pathname === "/api/estudiantes") {
      const resultado = await pool.query(
        "SELECT * FROM estudiantes ORDER BY id DESC",
      );

      enviarJSON(res, 200, resultado.rows);
      return;
    }

    if (req.method === "POST" && url.pathname === "/api/estudiantes") {
      const datos = await leerBody(req);

      const resultado = await pool.query(
        `INSERT INTO estudiantes 
        (carrera, facultad, tipo_id, identificacion, nombre, celular, correo, telefono, direccion)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
        RETURNING *`,
        [
          datos.carrera,
          datos.facultad,
          datos.tipo_id,
          datos.identificacion,
          datos.nombre,
          datos.celular,
          datos.correo,
          datos.telefono || null,
          datos.direccion || null,
        ],
      );

      enviarJSON(res, 201, {
        mensaje: "Estudiante registrado correctamente",
        estudiante: resultado.rows[0],
      });
      return;
    }

    if (req.method === "POST" && url.pathname === "/api/prestamos") {
      const datos = await leerBody(req);
      const cliente = await pool.connect();

      try {
        await cliente.query("BEGIN");

        const codigo = "PN-" + Date.now().toString().slice(-6);

        const prestamo = await cliente.query(
          `INSERT INTO prestamos 
          (codigo, tipo, periodo_academico, laboratorio, responsable, solicitante_tipo, estudiante_id)
          VALUES ($1, $2, $3, $4, $5, $6, $7)
          RETURNING *`,
          [
            codigo,
            "Préstamo Normal",
            datos.periodo_academico,
            datos.laboratorio,
            datos.responsable,
            datos.solicitante_tipo,
            datos.estudiante_id || null,
          ],
        );

        const prestamoId = prestamo.rows[0].id;

        if (Array.isArray(datos.articulos)) {
          for (const item of datos.articulos) {
            await cliente.query(
              `INSERT INTO articulos_prestamo 
              (prestamo_id, articulo, cantidad)
              VALUES ($1, $2, $3)`,
              [prestamoId, item.articulo, item.cantidad],
            );
          }
        }

        await cliente.query("COMMIT");

        enviarJSON(res, 201, {
          mensaje: "Préstamo guardado correctamente",
          prestamo: prestamo.rows[0],
        });
      } catch (error) {
        await cliente.query("ROLLBACK");
        throw error;
      } finally {
        cliente.release();
      }

      return;
    }

    if (req.method === "POST" && url.pathname === "/api/devoluciones") {
      const datos = await leerBody(req);

      const resultado = await pool.query(
        `INSERT INTO devoluciones 
        (prestamo_id, observacion)
        VALUES ($1, $2)
        RETURNING *`,
        [datos.prestamo_id, datos.observacion || null],
      );

      enviarJSON(res, 201, {
        mensaje: "Devolución registrada correctamente",
        devolucion: resultado.rows[0],
      });
      return;
    }

    // Carga del frontend: index.html, styles.css, script.js y assets.
    if (req.method === "GET") {
      servirArchivo(res, url.pathname);
      return;
    }

    enviarJSON(res, 404, { error: "Ruta no encontrada" });
  } catch (error) {
    console.error(error);
    enviarJSON(res, 500, {
      error: "Error en el servidor",
      detalle: error.message,
    });
  }
});

server.listen(PORT, () => {
  console.log(`Servidor funcionando en http://localhost:${PORT}`);
});
