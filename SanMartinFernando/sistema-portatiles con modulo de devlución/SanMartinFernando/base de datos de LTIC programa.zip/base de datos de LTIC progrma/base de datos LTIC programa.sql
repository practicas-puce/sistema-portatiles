CREATE TABLE estudiantes (
    id SERIAL PRIMARY KEY,
    carrera VARCHAR(100) NOT NULL,
    facultad VARCHAR(100) NOT NULL,
    tipo_id VARCHAR(20) NOT NULL,
    identificacion VARCHAR(20) UNIQUE NOT NULL,
    nombre VARCHAR(120) NOT NULL,
    celular VARCHAR(15) NOT NULL,
    correo VARCHAR(120) NOT NULL,
    telefono VARCHAR(15),
    direccion VARCHAR(200),
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE prestamos (
    id SERIAL PRIMARY KEY,
    codigo VARCHAR(30) UNIQUE NOT NULL,
    tipo VARCHAR(50) DEFAULT 'Préstamo Normal',
    periodo_academico VARCHAR(80),
    laboratorio VARCHAR(80),
    responsable VARCHAR(120),
    solicitante_tipo VARCHAR(30),
    estudiante_id INTEGER REFERENCES estudiantes(id),
    fecha_prestamo TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE articulos_prestamo (
    id SERIAL PRIMARY KEY,
    prestamo_id INTEGER REFERENCES prestamos(id) ON DELETE CASCADE,
    articulo VARCHAR(150) NOT NULL,
    cantidad INTEGER NOT NULL CHECK (cantidad > 0)
);

CREATE TABLE devoluciones (
    id SERIAL PRIMARY KEY,
    prestamo_id INTEGER REFERENCES prestamos(id),
    observacion TEXT,
    fecha_devolucion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);