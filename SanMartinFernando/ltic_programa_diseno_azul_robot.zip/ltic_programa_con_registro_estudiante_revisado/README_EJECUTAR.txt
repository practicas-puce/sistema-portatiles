PROYECTO LTIC - INSTRUCCIONES PARA EJECUTAR

1) Abrir una terminal en la carpeta backend:
   cd ltic_programa_con_registro_estudiante_revisado\backend

2) Instalar dependencias si hace falta:
   npm install

3) Ejecutar el servidor:
   npm start

4) Abrir en el navegador:
   http://localhost:3000

NOTAS:
- Ahora localhost:3000 carga el index.html del proyecto.
- La interfaz guarda estudiantes, préstamos, devoluciones y servicios en localStorage del navegador.
- El backend también tiene rutas /api, pero para usar PostgreSQL debes tener creada la base de datos ltic_prestamos y sus tablas.
